AI4 CUSTOMER TEMPLATE DEMOS

Purpose:
These are customer-selectable website template demos using AI4 Website Design as the sample subject so the design can be judged with real business content.

Open first:
ai4-template-demo-review-board.html

Templates:
1. template-option-01-private-signal-ai4-demo.html
2. template-option-02-launch-gallery-ai4-demo.html
3. template-option-03-command-deck-ai4-demo.html

Scope:
Static HTML/CSS only.
No Stripe, Supabase, Resend, Netlify Function, webhook, signup, sessionStorage, or backend logic was added or changed.

AI4 contact used:
jmitchell@ai4websitedesign.com

CTA path used:
offer.html
